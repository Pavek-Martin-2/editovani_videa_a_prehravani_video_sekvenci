@echo off
title play_Cekani_na_Patrika_1988.mp4

set file="Cekani_na_Patrika_1988.mp4"

set f="yes"

set m="no"

set sp="1"


set a01="00:39:19.686"
set b01="00:40:31.286"
mpv --fullscreen=%f% --mute=%m% --speed=%sp% --start=%a01% --end=%b01% %file%

pause
