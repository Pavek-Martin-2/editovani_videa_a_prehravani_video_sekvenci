@echo off
ffmpeg -i Cekani_na_Patrika_1988.mp4 -ss 00:39:19.686 -t 00:01:11.600 01_Cekani_na_Patrika_1988.mp4 -n

REM neni co s cim spojovat (pouze jedna scena)
REM ffmpeg -f concat -i "list_Cekani_na_Patrika_1988.txt" "spojene_Cekani_na_Patrika_1988.mp4" -n
pause
